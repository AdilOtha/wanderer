import { Map } from './map';

describe('Map', () => {
  it('should create an instance', () => {
    expect(new Map()).toBeTruthy();
  });
});
